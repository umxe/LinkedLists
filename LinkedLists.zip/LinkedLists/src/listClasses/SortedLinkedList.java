package listClasses;

import java.util.*;


/**
 * Implements a generic sorted list using a provided Comparator. It extends
 * BasicLinkedList class.
 * 
 *  @author Dept of Computer Science, UMCP
 *  
 */

public class SortedLinkedList<T> extends BasicLinkedList<T> {
	private Comparator<T> comparator;
	
	public SortedLinkedList(java.util.Comparator<T> comparator) {
		super();
		this.comparator = comparator;
	}
	
	public SortedLinkedList<T> add(T element){
		if(head == null) {
			head = new Node(element);
			tail = new Node(element);
			listSize += 1;
		}
		else {
			Node curr = head;
			Node tempN = new Node(element);
			
			while(curr != null) {
				if (comparator.compare(curr.data, element) >= 0){
					head = tempN;
					listSize += 1;
					tempN.next = curr;
					break;
				}
				else {
					if((curr.next == null) || (comparator.compare(curr.next.data, element)) > 0) {
						tempN.next = curr.next;
						curr.next = tempN;
						
						if(tempN.next == null) {
							tail = tempN;
						}
						else {
							listSize += 1; 
						}
						break;
					}
					else {
						curr = curr.next;
					}

				}
			}
		}
		
		return this;
	}
	
	public SortedLinkedList<T> remove(T targetData){
		super.remove(targetData, comparator);
		
		return this;
	}
	
	public BasicLinkedList<T> addToEnd(T data){
		throw new UnsupportedOperationException("Invalid operation for sorted list.");
	}
	
	public BasicLinkedList<T> addToFront(T data){
		throw new UnsupportedOperationException("Invalid operation for sorted list.");
	}

}