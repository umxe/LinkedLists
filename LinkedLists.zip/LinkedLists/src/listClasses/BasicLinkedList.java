package listClasses;

import java.util.*;


public class BasicLinkedList<T> implements Iterable<T> {
	
	/* Node definition */
	protected class Node {
		protected T data;
		protected Node next;

		protected Node(T data) {
			this.data = data;
			next = null;
		}
	}

	/* We have both head and tail */
	protected Node head, tail;
	
	/* size */
	protected int listSize;
	
	public BasicLinkedList() {
		this.head = null;
		this.tail = null;
		this.listSize = 0;
	}
	
	public int getSize() {
		return this.listSize;
	}
	
	public BasicLinkedList<T> addToEnd(T data){
		
		if(head == null) {
			this.tail = new Node(data);
			this.head = tail;
			listSize += 1;
		}
		else {
			Node prev = this.tail;
			this.tail = new Node(data);
			prev.next = this.tail;
			listSize += 1;
		}
		
		return this;
	}
	
	public BasicLinkedList<T> addToFront(T data){
		
		if(head == null) {
			this.head = new Node(data);
			this.tail = this.head;
			listSize += 1;
		}
		else {
			Node front = this.head;
			this.head = new Node(data);
			this.head.next = front;
			listSize += 1;
		}
		
		return this;
	}
	
	public T getFirst() {
		if(head == null) {
			return null;
		}
		else {
			return this.head.data;
		}
	}
	
	public T getLast() {
		if(tail == null) {
			return null;
		}
		else {
			return this.tail.data;
		}
	}
	
	public T retrieveFirstElement() {
		if(head == null) {
			return null;
		}
		else {
			this.listSize -= 1;
			Node firstElement = head;
			this.head = firstElement.next;
			return firstElement.data;
		}
	}
	
	public T retrieveLastElement() {
		if(tail == null) {
			return null;
		}
		else {
			this.listSize -= 1;
			Node curr = this.head;
			Node lastElement = this.tail;
			while(curr.next != this.tail) {
				curr = curr.next;
			}
			
			this.tail = curr;
			this.tail.next = null;
			return lastElement.data;
			
		}
	}
	
	public BasicLinkedList<T> remove(T targetData, java.util.Comparator<T> comparator){
		Node curr = head;
		Node prev = null;
		
		while(curr != null) {
			if(comparator.compare(curr.data, targetData) == 0) {
				this.listSize -= 1;
				if(curr == head) {
					this.head = this.head.next;
					curr = curr.next;
				}
				else {
					curr = curr.next;
					prev.next = curr;
				}
			}
			else {
				prev = curr;
				curr = curr.next;
			}
			
		}
		return this;
	}
	
	@Override
	public java.util.Iterator<T> iterator(){
		return new Iterator<T>() {
			private Node curr = head;
			private int num = 0;
			
			public void remove() {
				throw new UnsupportedOperationException("Do not need to Implement");
			}
			
			public T next() {
				if(curr == null) {
					throw new NoSuchElementException("No next element");
				}
				if(num == 0) {
					num += 1;
					return head.data;
				}
				else {
					num += 1;
					curr = curr.next;
					return curr.data;
				}
				
			}
			
			public boolean hasNext() {
				if(num < listSize) {
					return true;
				}
				return false;
			}
		};
	}
	
	public java.util.ArrayList<T> getReverseArrayList(){
		ArrayList<T> list = new ArrayList<T>();
		
		if(head == null) {
			return list;
		}
		else {
			getReverseArrayListHelper(list, head);
		}
		return list;
	}
	
	//Auxiliary Helper Method
	private void getReverseArrayListHelper(ArrayList<T> list, Node node) {
		
		if(node.next == null) {
			list.add(node.data);
			
		}
		else {
			getReverseArrayListHelper(list, node.next);
			
		}
	}
	
	public BasicLinkedList<T> getReverseList(){
		BasicLinkedList<T> list = new BasicLinkedList<T>();
		
		if(head == null) {
			return list;
		}
		else {
			getReverseListH(list, head);
		}
		return list;
	}
	
	//Auxiliary Helper Method
	private void getReverseListH(BasicLinkedList<T> list, Node node) {
		if(node.next == null) {
			list.addToEnd(node.data);
		}
		else {
			getReverseListH(list, node.next);
		}
	}
	
}