package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import listClasses.BasicLinkedList;

/**
 * 
 * You need student tests if you are looking for help during office hours about
 * bugs in your code.
 * 
 * @author UMCP CS Department
 *
 */
public class StudentTests {

	@Test
	public void bLLgetSize() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();
		
		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		assertEquals(3, basicList.getSize());
	}
	
	@Test
	public void bLLAddToEndGetLast() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();
		
		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		assertEquals("Red", basicList.getLast());
	}
	
	@Test
	public void bLLAddToFrontGetFirst() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();
		
		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		assertEquals("Blue", basicList.getFirst());
	}
	
	@Test
	public void bLLRetrieveFirst() {
		BasicLinkedList<String> basicList = new BasicLinkedList<String>();
		
		basicList.addToEnd("Red").addToFront("Yellow").addToFront("Blue");
		assertEquals("Blue", basicList.retrieveFirstElement());
	}

}
